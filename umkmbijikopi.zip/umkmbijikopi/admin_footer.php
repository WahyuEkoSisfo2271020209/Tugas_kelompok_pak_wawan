<body>
    <div class="container">
        <main class="content">
            <!-- Konten utama halaman -->
        </main>
        
       
            
        
        <footer>
            &copy; UMKM Kopi Lampung 2025 – All rights reserved
        </footer>
    </div>
</body>
</html>